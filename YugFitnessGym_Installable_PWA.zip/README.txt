YUG FITNESS GYM — INSTALLABLE PWA PACKAGE
Files:
- index.html: app
- manifest.json: install metadata
- sw.js: offline caching
- icon.svg: app icon

IMPORTANT:
PWA installation and service workers require HTTPS hosting (or localhost). Opening index.html from file:// will not enable install/offline service worker features.
This package is NOT cloud synced and has no secure login yet. Local member records remain on one browser/device. Before real gym use, make a JSON backup regularly.

Quick hosting route from Android:
1. Create a GitHub account and a repository named yug-fitness-gym.
2. Upload all four files in this package to repository root.
3. Repository Settings -> Pages -> Deploy from branch -> main -> /(root).
4. Wait for the Pages URL. Open it in Chrome on Android.
5. Chrome menu -> Add to Home screen / Install app.
